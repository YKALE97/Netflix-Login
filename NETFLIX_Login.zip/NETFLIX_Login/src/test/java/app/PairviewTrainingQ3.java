package app;


import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class PairviewTrainingQ3 {
    private WebDriver driver;
    private final String expectedTitle = "Build a career in fast growing fields. Only at Pairview | Pairview Training";
    private final String websiteUrl = "https://www.pairviewtraining.com/";

    @BeforeMethod
    public void setUp() {
        // Setup ChromeDriver using WebDriverManager
        WebDriverManager.chromedriver().setup();

        // Create a new instance of ChromeDriver
        driver = new ChromeDriver();
    }

    @Test
    public void verifyHomePageTitle() {
        // Open the website
        driver.get(websiteUrl);

        // Get the title of the homepage
        String actualTitle = driver.getTitle();

        // Verify if the actual title matches the expected title
        Assert.assertEquals(actualTitle, expectedTitle, "Homepage title doesn't match the expected value.");
    }

    @AfterMethod
    public void tearDown() {
        // Close the browser
        driver.quit();
    }
}
