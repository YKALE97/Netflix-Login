package app;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class NetflixLogin {

	public static String browser = "Chrome"; // External configuration - XLS, CSV
	public static WebDriver driver;
//	public static FirefoxDriver driver;
	
	public static void main(String[] args) throws InterruptedException {

		if (browser.equals("Firefox")) {
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
		} else if (browser.equals("Chrome")) {
			WebDriverManager.chromedriver().setup();
//			ChromeDriver driver = new ChromeDriver();
			driver = new ChromeDriver();
		}else if (browser.equals("Edge")) {
			WebDriverManager.edgedriver().setup();
//			ChromeDriver driver = new ChromeDriver();
			driver = new EdgeDriver();
		}

		driver.get("https://www.netflix.com/gb/");
		driver.manage().window().maximize();
		Thread.sleep(2000);
        driver.findElement(By.xpath("//*[@id=\"cookie-disclosure-accept\"]")).click();
        driver.findElement(By.xpath("//*[@id=\"appMountPoint\"]/div/div/div/div/div/div/header/div/span[3]/a")).click();
		driver.findElement(By.id("id_userLoginId")).sendKeys("Kabirpotbhare6888@gmail.com");
		Thread.sleep(2000);
		driver.findElement(By.id("id_password")).sendKeys("Potbhare2000");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='appMountPoint']/div/div[3]/div/div/div[1]/form/button")).click();
		driver.close();
	}

}
